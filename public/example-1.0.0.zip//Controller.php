<?php

namespace App\Core\example;

use App\Core\BaseController;
use Illuminate\Http\Request;

class Controller extends BaseController
{

    public function index()
    {
        return view('example::tes');
    }
}