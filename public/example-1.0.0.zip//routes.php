<?php

Route::group([
    'prefix' => plugin()->getAdminRoutePrefix()
], function(){
    Route::get('/tes', 'Controller@index')->name('tes');
    Route::get('/blank', function(){
        return "blank page with closure action";
    })->name('blank');
});