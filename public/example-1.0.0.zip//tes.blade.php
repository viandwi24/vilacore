@extends('layouts.admin')

@section('title', admin()->getAdminTitlePage('Example Page Blank'))

@section('content.header')
    {!! admin()->contentHeader('Example Page Blank' , [['name' => 'Admin'], ['name' => 'Example', 'link' => '']]) !!}
@endsection

@section('content')
    tes page blank with extends admin layouts
@stop