@extends('layouts.admin')

@section('content.header')
    {!! plugin()->getContentHeaderSettingPage() !!}          
@stop

@section('content')
    tes
@stop